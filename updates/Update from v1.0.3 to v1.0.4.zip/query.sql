UPDATE brands SET name = JSON_OBJECT('en', name);

ALTER TABLE `brands` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE categories SET name = JSON_OBJECT('en', name);

ALTER TABLE `categories` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE category_sliders SET title = JSON_OBJECT('en', title);

ALTER TABLE `category_sliders` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE taxes SET title = JSON_OBJECT('en', title);

ALTER TABLE `taxes` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE cities SET name = JSON_OBJECT('en', name);

ALTER TABLE `cities` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE blog_categories SET name = JSON_OBJECT('en', name);

ALTER TABLE `blog_categories` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE blogs SET title = JSON_OBJECT('en', title);

ALTER TABLE `blogs` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE offers SET title = JSON_OBJECT('en', title);

ALTER TABLE `offers` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE  offer_sliders SET title = JSON_OBJECT('en', title);

ALTER TABLE `offer_sliders` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE  sections SET title = JSON_OBJECT('en', title);

ALTER TABLE `sections` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE  sections SET short_description = JSON_OBJECT('en', short_description );

ALTER TABLE `sections` CHANGE `short_description` `short_description` JSON NULL DEFAULT NULL;

UPDATE  stores SET name = JSON_OBJECT('en', name);

ALTER TABLE `stores` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE  stores SET description = JSON_OBJECT('en', description);

ALTER TABLE `stores` CHANGE `description` `description` JSON NULL DEFAULT NULL;

UPDATE  promo_codes SET title = JSON_OBJECT('en', title);

ALTER TABLE `promo_codes` CHANGE `title` `title` JSON NULL DEFAULT NULL;

UPDATE  promo_codes SET message = JSON_OBJECT('en', message);

ALTER TABLE `promo_codes` CHANGE `message` `message` JSON NULL DEFAULT NULL;

UPDATE  zones SET name = JSON_OBJECT('en', name);

ALTER TABLE `zones` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE  products SET name = JSON_OBJECT('en', name);

ALTER TABLE `products` CHANGE `name` `name` JSON NULL DEFAULT NULL;

UPDATE  products SET short_description = JSON_OBJECT('en', short_description);

ALTER TABLE `products` CHANGE `short_description` `short_description` JSON NULL DEFAULT NULL;

UPDATE  combo_products SET title = JSON_OBJECT('en', title);

ALTER TABLE `combo_products` CHANGE `title` `title` JSON NULL DEFAULT NULL;


UPDATE  combo_products SET short_description = JSON_OBJECT('en', short_description);

ALTER TABLE combo_products 
MODIFY COLUMN short_description JSON NULL DEFAULT NULL;

ALTER TABLE `zones` CHANGE `serviceable_city_ids` `serviceable_city_ids` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL;


ALTER TABLE `zones` CHANGE `serviceable_zipcode_ids` `serviceable_zipcode_ids` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL;


